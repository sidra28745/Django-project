from django.contrib import admin
from .models import teacher

# Register your models here.
admin.site.register(teacher)