"""
Package for DjangoProj.
"""
